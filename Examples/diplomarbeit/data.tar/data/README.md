This is a normalised version of an OWL EL version of the Galen
ontology, taken from the [KR2020
Tutorial](https://iccl.inf.tu-dresden.de/web/Rules_KR_Tutorial_2020).
